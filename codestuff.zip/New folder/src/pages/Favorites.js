function FavoritesPage() {
    return <div>Favorites Page</div>;
}

export default FavoritesPage;